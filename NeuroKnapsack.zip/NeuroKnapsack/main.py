
# coding: utf-8

# In[1]:

#get_ipython().magic(u'matplotlib inline')


# In[2]:

from keras.constraints import maxnorm, Constraint
from keras.layers import Input, Masking, GRU, merge, Dense, TimeDistributed, BatchNormalization, Activation, Dropout,     Conv1D, RepeatVector ,Lambda
from keras.models import Model
from keras.layers import concatenate,Bidirectional
from keras.layers.merge import Add, Dot , Multiply
from keras.initializers import RandomUniform, RandomNormal
import keras.backend as K
import numpy as np
from keras.optimizers import RMSprop, Adam, SGD,Adadelta
from keras.callbacks import LambdaCallback, ModelCheckpoint, EarlyStopping,CSVLogger,LearningRateScheduler
from keras import regularizers
from time import time
import math
from imports.clr_callback import CyclicLR

# In[3]:

def greedyKnapsack(values, weights, cap):
    ratios = [values[i] / float(weights[i]) for i in range(len(values))]
    indices = np.argsort(ratios)
    indices = np.flip(indices,0)
    ratios.sort()


    y = np.zeros((len(ratios), 2))

    for i in range(0, len(ratios)):
        # take item
        y[indices[i], 1] = 1
        y[indices[i], 0] = 0

        if checkcapacity(weights, y, cap):
            # if there still capacity take the item
            y[indices[i], 0] = 0
            y[indices[i], 1] = 1
        else:
            # don't take the item
            y[indices[i], 0] = 1
            y[indices[i], 1] = 0
    return y


# In[4]:

def checkcapacity(weights, y_, cap):
    y_ = np.argmax(y_, axis=-1)
    sum = 0.0
    for i in range(len(weights)):
        sum += weights[i] * y_[i]

    if sum <= cap:

        return True
    else:
        return False



# In[5]:

def getcost(values, y_):
    sum = 0.0
    y_ = np.argmax(y_, axis=-1)
    for i in range(len(y_)):
        sum += values[i] * y_[i]
    return sum


# In[6]:

def problems_accuracy(y, y_p, n,verbose=False):
    reward = 0
    y = np.argmax(y, axis=-1)
    y_p = np.argmax(y_p, axis=-1)
    for i in range(n):
        if y[i] == y_p[i]:
            if verbose:
                print (i,y[i], '-----', y_p[i])
            reward += 1
        else:
            if verbose:
                print ('WRONG' ,i,y[i], '-----' ,y_p[i])
    #print reward

    if reward == n:
        return 1, reward
    else:
        return 0, reward


# In[7]:

def load_data(files):
    return np.load(files[0]) , np.load(files[1]) , np.load(files[2])


# In[8]:

def seq2seq(hidden,  mem_layers = 1 , dropout=0.0,optimizer = None, load_weights=False, model_name=None):
    encoder_inputs = Input(shape=(None, 3))
    #inputs_masking = Masking(mask_value=-1.0)
     #memory-construction

    sm = TimeDistributed(Dense(hidden, activation='relu' ,use_bias=False))(encoder_inputs)
    sm = Dropout(dropout)(sm)
    for _ in range(mem_layers-1):
        sm = TimeDistributed(Dense(hidden,activation='relu',use_bias=False))(sm)
        sm = Dropout(dropout)(sm)
    encoder = GRU(hidden, dropout=dropout,
             kernel_initializer=RandomUniform(-0.08, 0.08), return_sequences=True)(encoder_inputs)
    encoder = GRU(hidden, dropout=dropout,
             kernel_initializer=RandomUniform(-0.08, 0.08), return_sequences=True)(encoder)
    encoder , state_1 = GRU(hidden, dropout=dropout,
             kernel_initializer=RandomUniform(-0.08, 0.08), return_state=True)(encoder)
    reg_cost = Dense(hidden)(encoder)
    reg_cost = Dense(1,name='reg_cost')(reg_cost)
    decoder_inputs = Input(shape=(None, 3))
    decoder_tm1 =  Input(shape=(None,None, 2))
    #_masking = Masking(mask_value=0.0)
    decoder_tm1_f = TimeDistributed(GRU(hidden,  dropout=dropout,
             kernel_initializer=RandomUniform(-0.08, 0.08),return_sequences=False))(decoder_tm1)
    decoder_inputs_f = concatenate([decoder_inputs, decoder_tm1_f])
    sim = Dot(-1,normalize = True, name='cos_sim')
    read_weights = Activation('softmax')
    read_vector = Lambda(lambda x: K.batch_dot(x[0],x[1]),name='read_vector')
    decoder_gru = GRU(hidden,  dropout=dropout,
             kernel_initializer=RandomUniform(-0.08, 0.08),return_sequences=True,return_state=True)
    decoder_gru_1 = GRU(hidden,  dropout=dropout,
             kernel_initializer=RandomUniform(-0.08, 0.08),return_sequences=True)
    decoder_gru_2 = GRU(hidden,  dropout=dropout,
             kernel_initializer=RandomUniform(-0.08, 0.08),return_sequences=True)
    decoder_gru_3 = GRU(hidden,  dropout=dropout,
             kernel_initializer=RandomUniform(-0.08, 0.08),return_sequences=True)
    decoder_dense = Dense(2, activation='softmax', name='output')

    decoder_outputs,_ = decoder_gru(decoder_inputs_f,initial_state=state_1)
    #decoder 1
    decoder_outputs  = decoder_gru_1(decoder_outputs)
    sim_score = sim([decoder_outputs, sm])
    weights = read_weights(sim_score)
    rt = read_vector([weights,sm])
    #decoder 2
    decoder_outputs = decoder_gru_2(concatenate([decoder_outputs,rt]))
    sim_score = sim([decoder_outputs, sm])
    weights = read_weights(sim_score)
    rt = read_vector([weights,sm])
    #decoder 3
    decoder_outputs = decoder_gru_3(concatenate([decoder_outputs,rt]))
    sim_score = sim([decoder_outputs, sm])
    weights = read_weights(sim_score)
    rt = read_vector([weights,sm])
    decoder_outputs = decoder_dense(concatenate([decoder_outputs,rt]))
    model = Model([encoder_inputs,decoder_inputs, decoder_tm1], [decoder_outputs,reg_cost])

    #encoder model
    encoder_model = Model(encoder_inputs, [state_1,sm])
    #decoder model
    decoder_state_input = Input(shape=(hidden,))
    sm_input = Input(shape=(None,hidden))
    decoder_outputs, state_h  = decoder_gru(decoder_inputs_f, initial_state=decoder_state_input)
    #decoder 1
    decoder_outputs  = decoder_gru_1(decoder_outputs)
    sim_score = sim([decoder_outputs, sm_input])
    weights = read_weights(sim_score)
    rt = read_vector([weights,sm_input])
    #decoder 2
    decoder_outputs = decoder_gru_2(concatenate([decoder_outputs,rt]))
    sim_score = sim([decoder_outputs, sm_input])
    weights = read_weights(sim_score)
    rt = read_vector([weights,sm_input])
    #decoder 3
    decoder_outputs = decoder_gru_3(concatenate([decoder_outputs,rt]))
    sim_score = sim([decoder_outputs, sm_input])
    weights = read_weights(sim_score)
    rt = read_vector([weights,sm_input])
    decoder_outputs = decoder_dense(concatenate([decoder_outputs,rt]))

    decoder_model = Model(
        [sm_input,decoder_inputs,decoder_tm1] + [decoder_state_input],
        [decoder_outputs] + [state_h,rt])
    model.compile(optimizer=optimizer,
                    loss={'output':'binary_crossentropy', 'reg_cost':'mse'},
                    metrics={'output':'accuracy'})
    return model , encoder_model , decoder_model


# In[9]:

def decode_sequence(input_seq):
    # Encode the input as state vectors.
    states , sm = encoder.predict(input_seq)
    # Generate empty target sequence of length 1.
    target_seq = np.zeros((1, 1,MAX_N, 2))
    #output_tokens = np.zeros((1, 1, 2))
    input_decoder_seq = np.zeros((1,1, 3))
    #rt_input = np.zeros((1, 1, hidden))
    # Populate the first character of target sequence with the start character.
    #target_seq[0, 0, target_token_index['\t']] = 1.

    # Sampling loop for a batch of sequences
    # (to simplify, here we assume a batch of size 1).
    stop_condition = False
    y_p = np.zeros((MAX_N,2))
    #rt_ = np.zeros((N,hidden))
    _i = 0
    #c = 0
    #cap = input_seq[0,_i,2] * 1000.0
    while not stop_condition:
        input_decoder_seq[0,0] = input_seq[0,_i]
        output_tokens, states, rt = decoder.predict(
            [sm,input_decoder_seq,target_seq] + [states])

        # Sample a token
        _index = np.argmax(output_tokens[0, -1, :])
        #c+= input_seq[0,_i,1] * 1000.0

        # Exit condition: either hit max length
        # or find stop character.
        #if _i <= N-2:

        #    rt_input[0, 0,:] = rt
        #    rt_[_i+1] = rt
        if _i >= MAX_N-1:
            stop_condition = True
        # Update the target sequence (of length 1).


        #target_seq = np.zeros((1, 1, 2))
        target_seq[0, 0, _i,_index] = 1.
        #target_seq[0, 0, _index] = 1.

        y_p[_i] = target_seq[0,0,_i]
        _i+=1
        # Update states
        #states_value = [s1,s2]

    return y_p, rt


# In[10]:

#GRU vs Greedy
approx_list =[500.0]
wait = 0
def evaluate(epoch,log):
    y_p = np.zeros((MAX_N,2))
    acc = 0
    gru_feas = 0
    feas_greedy = 0
    solver_costs = 0
    gru_costs = 0
    greedy_costs = 0
    total_correct_variables = 0
    infeas = 0
    #max_v = np.amax(x_w_c)
    #print max_v
    test_set = x_val.shape[0]
    for _i in range(test_set):
        #_i = probs[__i]
        weights = []
        values = []
        for t in range(MAX_N):
            weights.append(x_val[_i, t, 1])
            values.append(x_val[_i, t, 0])
        #x_val_t = np.zeros((1,N,1))
        #x_w_c_t = np.zeros((1,N+2,1))
        #x_val_t[:,:,0] = x_val[_i,:,0] / max_1
        #x_val_t = x_val / 19600.0
        #x_w_c_t[:,:,0] = x_w_c[_i,:,0] / max_2
        #x_w_c_t[:,-2,0] = -1.0
        y_p, rt = decode_sequence(x_val[_i:_i+1])
        #print sum(weights) ,  x_val[_i, 0, 2]
        if checkcapacity(weights, y_p, x_val[_i, 0, 2]):
            gru_costs+= getcost(values,y_p)
            gru_feas+=1
            y = greedyKnapsack(values, weights, x_val[_i, 0, 2])
            if checkcapacity(weights, y, x_val[_i, 0, 2]):
                feas_greedy += 1
                greedy_costs += getcost(values, y)
                #optimial
                solver_costs += obj_val[_i]
                es , reward = problems_accuracy(y_val[_i], y_p, MAX_N)
                if es == 1:
                    acc += 1
                total_correct_variables += reward
        else:
            #continue

            infeas+=1
            indices = np.argsort(weights)
            indices = np.flip(indices,0)
            for w,v in enumerate(indices):
                #print _i, w
                if np.argmax(y_p[w]) == 1:
                    y_p[w,0] = 1
                    y_p[w,1] = 0
                    if checkcapacity(weights, y_p,x_val[_i, 0, 2]):
                        gru_costs+= getcost(values,y_p)
                        gru_feas+=1
                        y = greedyKnapsack(values, weights,x_val[_i, 0, 2])
                        feas_greedy += 1
                        greedy_costs += getcost(values, y)
                        solver_costs += obj_val[_i]
                        es , reward = problems_accuracy(y_val[_i], y_p, MAX_N)
                        if es == 1:
                            acc += 1
                        total_correct_variables += reward
                        break

    gru_approx = max(solver_costs / gru_costs, gru_costs / solver_costs)
    #if len(approx_list) == 0:
    #    approx_list = [500.0]
    global wait
    global  approx_list
    if gru_approx >= approx_list[-1]:

        if wait >= 5:
            model.stop_training = True
            wait = 0

            #approx_list = [500.0]
            #approx_list.clear()

        else:
            wait+=1
            approx_list.append(gru_approx)

    else:
        approx_list.append(gru_approx)

    print '\r'
    print infeas
    print('total number of correct variables:' , total_correct_variables / float(test_set*MAX_N))
    print ('number of feasible sols (greedy):', feas_greedy/ float(test_set))
    print ('greedy costs:', greedy_costs)
    print ('solver costs:', solver_costs)
    print ('GRU costs:', gru_costs)
    print ('accuracy:', acc / float(test_set))
    print ('number of feasible sols(GRU):', gru_feas / float(test_set))
    print ('Approx. ratio for GRU:', max(solver_costs / gru_costs, gru_costs / solver_costs))
    print ('Approx. ratio for greedy algorithm:', max(solver_costs / greedy_costs, greedy_costs / solver_costs))


# In[11]:

#optimizer = SGD(lr=0.1, momentum=0.9, nesterov=False) # decrement learning rate
optimizer = Adam(lr=4e-3,clipnorm=1.0)
#optimizer  = RMSprop(clipnorm=1.0)
np.random.seed(50)
hidden =  200
N = 2
MAX_N = 5
train_instances = 100000
size = 'large'

# In[12]:

model,encoder,decoder = seq2seq(hidden,1, dropout=0.0, optimizer=optimizer)
model.summary()
#model.load_weights('.models/neuroknapsack-2-large.hdf5')

# In[14]:

evaluate_callback = LambdaCallback(on_epoch_end=evaluate)
csv_logger = CSVLogger('logs/training_'+str(MAX_N)+'VARs_units.log')
def step_decay(epoch):
   initial_lrate = 0.001
   drop = 0.5
   epochs_drop = 1.0
   lrate = initial_lrate * math.pow(drop,
           math.floor((1+epoch)/epochs_drop))
   return lrate
lrate = LearningRateScheduler(step_decay)

# In[15]:
clr = CyclicLR(base_lr=0.001, max_lr=0.006,
                        step_size=1000., mode='triangular2')
#checkpointer = ModelCheckpoint(filepath='models/seq2seq_10model.hdf5', verbose=1,save_best_only=True,monitor='val_acc')


# In[16]:

x_train_v_w_c_f ,obj_train, y_train_f = load_data(['data/train/vwc_train_mixed_5.npy', 'data/train/objectives_train_mixed_5.npy','data/train/output_train_mixed_5.npy'])
#x_train_v_w_c_f /= np.max(x_train_v_w_c_f)


#x_train_v_w_c_f2, obj_train2, y_train_f2 = load_data(['data/vwc_train2_10.npy', 'data/objectives_train2_10.npy', #'data/output_train2_10.npy'])
#x_train_v_w_c_f = np.concatenate((x_train_v_w_c_f1 , x_train_v_w_c_f2))
#obj_train = np.concatenate((obj_train1 , obj_train2))
#y_train_f =  np.concatenate((y_train_f1 , y_train_f2))
#obj_train_f = np.array(obj_train)
y_tm1_f = np.zeros((train_instances,MAX_N,MAX_N,2))
for t in range(MAX_N):
    y_tm1_f[:, t, 0:t, :] = y_train_f[:, 0:t, :]
x_val , obj_val , y_val = load_data(['data/test/vwc_test_5.npy', 'data/test/objectives_test_5.npy', 'data/test/output_test_5.npy'])
obj_train_f = np.array(obj_train)
#obj_train_f /= np.max(obj_train_f)
print x_val[0]
# In[12]:




# In[ ]:

model.fit([x_train_v_w_c_f,x_train_v_w_c_f,y_tm1_f],[y_train_f,obj_train_f], shuffle= True, epochs=30,batch_size=100,callbacks=[csv_logger,evaluate_callback])
model.save('.models/neuroknapsack-'+ str(MAX_N)+'-'+size+'.hdf5')
with open('approx_ratios.txt', 'w') as f:
    for item in approx_list:
        print >> f, item

# In[ ]:
